#! /bin/bash

CURRENT_DIR=`pwd`


SOL_DIR=$CURRENT_DIR/sol/

UNIT_TEST_DIR=$CURRENT_DIR/unit_test_files/

TMP_DIR=$CURRENT_DIR/tmp/
HDR_DIR=$CURRENT_DIR/headers/

mkdir -p $TMP_DIR
rm -rf $TMP_DIR/*

#	-------------------------------------------------------------------------------------------->

test_stud_sol() {
	
	cd $SOL_DIR/
	
	# check if README file exists
	if [ ! -e README ]; then
		
		echo
		echo "Error: No README file!" 
		echo
		return
	fi
	
	# add an entry in the errors file
	echo "Users: " 
	head README -n 1 
	
	# copy the files to tmp dir with the headers
	cp -r ./* $TMP_DIR/
	cp $HDR_DIR/* $TMP_DIR/
	
	# create the lib
	cd $TMP_DIR/
	echo
	echo "Creating the lib..."
	make 2> /dev/null  1>&2
	
	if [ $? != 0 ]; then
		# error while compilation
		echo "Error: Creation of the lib failed! "
		
		return
	fi
	
	if [ ! -e "ex2.a" -a ! -e "libex2.a" ]; then
	
		# no lib file
		echo
		echo " Error: Wrong lib name " 
		return
		
	fi
	
	# change the name of the lib 
	if [ -e "libex2.a"  ]; then
		mv libex2.a ex2.a
	fi
	
	# copy the lib to the unit test folder
	cp ex2.a $UNIT_TEST_DIR/arc-elf/
	
	# check whether the ivt.s exists
	if [ ! -e "ivt.s" ]; then 
		echo
		echo "Error: No ivt file!"
		return
	fi

	# compile the ivt	
	mcc -a6 -c ivt.s -o $UNIT_TEST_DIR/arc-elf/ivt.o 2> /dev/null  1>&2
	if [ $? != 0 ]; then 
		echo
		echo "Error during compilation of ivt.s!"
		return
	fi
	
	# compile the unit tests with the archive of the student
	echo
	echo "Linking with unit test"
	make -C $UNIT_TEST_DIR 2> /dev/null  1>&2

	if [ $? != 0 ]; then 
		echo
		echo "Error: linking with unit test failed!"
		return
	fi
	
	rm -rf $TMP_DIR/*
	
}

test_stud_sol

echo
echo "Compilation done - make sure there are no errors"
echo

# return to the directory that this script was invoked
cd $CURRENT_DIR
